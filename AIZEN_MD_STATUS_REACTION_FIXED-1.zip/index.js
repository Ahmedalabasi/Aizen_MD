'use strict';
const pino=require('pino');
const fs=require('fs');
const path=require('path');
const {default:makeWASocket,useMultiFileAuthState,DisconnectReason,jidNormalizedUser,fetchLatestBaileysVersion}=require('@whiskeysockets/baileys');
const config=require('./config'),store=require('./lib/store'),ai=require('./lib/ai'),menu=require('./menu'),statusSection=require('./sections/status');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const digits=x=>String(x||'').replace(/\D/g,'');
const owners=[...config.OWNER_NUMBERS,config.BOT_NUMBER].map(digits);
const flood=new Map(), repeats=new Map(), spamMap=new Map(), metaCache=new Map(), violations=new Map();
let restarting=false, socket=null, reconnectTimer=null, pairingRequested=false;
const menuMessages=new Map();
const MENU_IMAGE=path.join(__dirname,'assets','aizen-menu.jpg');
const MENU_IMAGE_BUFFER=fs.readFileSync(MENU_IMAGE);
const MENU_CHANNEL='https://whatsapp.com/channel/0029VbDpE676hENheD1pTu2g';
const fun={
 'نكتة':['مرة واحد نام متأخر… فاته الحلم 😂','واحد اشترى ساعة ضد الماء… عطشها.'],
 'لغز':['ما الشيء الذي كلما أخذت منه كبر؟ الحفرة.','له أسنان ولا يعض؟ المشط.'],
 'حقيقة':['الأخطبوط لديه ثلاثة قلوب.','العسل الطبيعي قد يبقى صالحًا لسنوات طويلة إذا حُفظ جيدًا.'],
 'اقتباس':['ابدأ من حيث أنت، واستخدم ما لديك.','النجاح خطوات صغيرة تتكرر كل يوم.'],
 'تحدي':['تحداك تكتب اسمك بيدك غير المعتادة!','اذكر ثلاثة أشياء تبدأ بحرف م خلال خمس ثوانٍ.'],
 'سؤال':['لو تقدر تسافر الآن لأي مكان، وين بتروح؟','ما المهارة التي تتمنى تتقنها؟']
};
const AI_COMMANDS=['اسأل','ذكاء','حلل','لخص','ترجم','اكتب','صحح','اشرح','ابحث','اقترح','حل','تعلم'];
const PROTECTION=['links','duplicate','spam','flood','badwords','mentions','stickers','images','videos','audio','destructive'];
const RANDOM_EMOJIS=['❤️','🤍','💚','💙','💜','🔥','😍','😂','✨','👍'];
const badWords=['كلب','حمار','غبي'];
function textOf(m){const x=m?.ephemeralMessage?.message||m?.viewOnceMessage?.message||m;return x?.conversation||x?.extendedTextMessage?.text||x?.imageMessage?.caption||x?.videoMessage?.caption||x?.documentMessage?.caption||'';}
function isOwner(jid){return owners.includes(digits(String(jid||'').split('@')[0]));}
function isGroup(jid){return String(jid||'').endsWith('@g.us');}
function isUrl(s){return /https?:\/\/|www\.|chat\.whatsapp\.com\//i.test(s||'');}
function chunks(s,max=3500){const out=[];let cur='';for(const line of String(s).split('\n')){if((cur+'\n'+line).length>max&&cur){out.push(cur);cur=line;}else cur+=(cur?'\n':'')+line;}if(cur)out.push(cur);return out;}
function getTarget(msg){const c=msg.message?.extendedTextMessage?.contextInfo;return c?.mentionedJid?.[0]||c?.participant||null;}
function keyFor(jid,user){return jid+':'+user;}
function groupCfg(jid){const all=store.get().groups;return all[jid]||(all[jid]={});}
async function getMeta(sock,jid){const c=metaCache.get(jid);if(c&&Date.now()-c.at<config.META_CACHE_MS)return c.value;const value=await sock.groupMetadata(jid);if(metaCache.size>250)metaCache.delete(metaCache.keys().next().value);metaCache.set(jid,{at:Date.now(),value});return value;}
function msgType(m){const x=m.message||{};if(x.imageMessage)return 'images';if(x.videoMessage)return 'videos';if(x.audioMessage||x.pttMessage)return 'audio';if(x.stickerMessage)return 'stickers';return 'text';}
function addViolation(jid,user,reason){const k=keyFor(jid,user);const a=store.get().violations[k]||[];a.push({at:new Date().toLocaleString('ar'),reason});if(a.length>30)a.shift();store.get().violations[k]=a;store.log(`${jid} | ${user} | مخالفة: ${reason}`);}
async function send(sock,jid,text,quoted){for(const part of chunks(text))await sock.sendMessage(jid,{text:part},quoted?{quoted}:{});}
async function adminInfo(sock,jid,sender){const md=await getMeta(sock,jid);const bot=jidNormalizedUser(sock.user.id);const admins=md.participants.filter(p=>p.admin).map(p=>jidNormalizedUser(p.id));return {md,admins,senderAdmin:admins.includes(jidNormalizedUser(sender)),botAdmin:admins.includes(bot)};}
async function makeImage(sock,jid,prompt,quoted){const q=encodeURIComponent(String(prompt||'').slice(0,300));if(!q)throw new Error('اكتب وصف التصميم بعد الأمر.');const url=`https://image.pollinations.ai/prompt/${q}?width=768&height=1024&nologo=true`;const r=await fetch(url,{signal:AbortSignal.timeout(60000)});if(!r.ok)throw new Error('خدمة التصميم غير متاحة حاليًا.');const buf=Buffer.from(await r.arrayBuffer());if(buf.length>8*1024*1024)throw new Error('حجم الصورة الناتجة كبير.');await sock.sendMessage(jid,{image:buf,caption:`✦ 𝐀𝐈𝐙𝐄𝐍 𝐌𝐃
${prompt}`},{quoted});}
async function cobalt(url, mode='auto'){
 const endpoint=process.env.COBALT_API_URL||'https://api.cobalt.tools/';
 const r=await fetch(endpoint,{method:'POST',headers:{'Accept':'application/json','Content-Type':'application/json','Origin':'https://cobalt.tools','Referer':'https://cobalt.tools/'},body:JSON.stringify({url,downloadMode:mode,filenameStyle:'pretty',youtubeVideoCodec:'h264',youtubeAudioFormat:'mp3'}) ,signal:AbortSignal.timeout(45000)});
 const data=await r.json().catch(()=>({}));
 if(!r.ok||!['tunnel','redirect','success'].includes(data.status)||!data.url)throw new Error(data.text||'خدمة التنزيل غير متاحة حالياً لهذا الرابط.');
 return data.url;
}
async function fetchMedia(url){
 const r=await fetch(url,{signal:AbortSignal.timeout(60000)});if(!r.ok)throw new Error('تعذر تنزيل الملف من الخدمة.');
 const len=Number(r.headers.get('content-length')||0);if(len>45*1024*1024)throw new Error('حجم الملف أكبر من حد الإرسال (45MB).');
 const b=Buffer.from(await r.arrayBuffer());if(b.length>45*1024*1024)throw new Error('حجم الملف أكبر من حد الإرسال (45MB).');return b;
}
async function youtubeSearch(q){
 const yt=require('yt-search');const r=await yt(q);return (r.videos||[]).slice(0,5);
}
async function handleDownload(sock,msg,jid,cmd,arg,reply){
 if(cmd==='جوجل'){
  if(!/^https?:\/\//i.test(arg))return reply('الصق رابط الصورة بعد الأمر.');
  const r=await fetch(arg,{signal:AbortSignal.timeout(30000),redirect:'follow'});
  if(!r.ok)throw new Error('تعذر جلب الصورة من الرابط.');
  const type=(r.headers.get('content-type')||'').toLowerCase();
  if(!type.startsWith('image/'))throw new Error('الرابط لا يشير إلى صورة مباشرة.');
  const buf=Buffer.from(await r.arrayBuffer());
  if(buf.length>8*1024*1024)throw new Error('حجم الصورة أكبر من 8MB.');
  await sock.sendMessage(jid,{image:buf,caption:'✦ 𝐀𝐈𝐙𝐄𝐍 𝐌𝐃'},{quoted:msg});
  return true;
 }
 if(cmd==='جيت'){
  if(!arg)return reply('اكتب اسم المشروع للبحث عنه في GitHub.');
  const r=await fetch('https://api.github.com/search/repositories?q='+encodeURIComponent(arg)+'&sort=stars&per_page=5',{headers:{'Accept':'application/vnd.github+json','User-Agent':'AIZEN-MD'},signal:AbortSignal.timeout(20000)});
  if(!r.ok)throw new Error('تعذر البحث في GitHub الآن.');const d=await r.json();
  return reply((d.items||[]).map((x,i)=>`${i+1}. ${x.full_name}\n⭐ ${x.stargazers_count} | ${x.html_url}\n${(x.description||'بدون وصف').slice(0,180)}`).join('\n\n')||'لم أجد مشاريع مطابقة.');
 }
 if(cmd==='فيديو'||cmd==='شغل'){
  if(!arg)return reply(cmd==='شغل'?'اكتب اسم المقطع أو رابط يوتيوب.':'أرسل رابط فيديو مباشر أو رابط منصة مدعومة.');
  let url=arg;
  if(!/^https?:\/\//i.test(url)){
   const videos=await youtubeSearch(arg);if(!videos.length)return reply('لم أجد نتائج فيديو.');
   url=videos[0].url;
  }
  await sock.sendMessage(jid,{text:'⏳ جاري تجهيز الملف...'});
  const dl=await cobalt(url,cmd==='شغل'?'audio':'auto');const buf=await fetchMedia(dl);
  if(cmd==='شغل')await sock.sendMessage(jid,{audio:buf,mimetype:'audio/mpeg',fileName:'AIZEN-MD.mp3'},{quoted:msg});
  else await sock.sendMessage(jid,{video:buf,mimetype:'video/mp4',caption:'✦ 𝐀𝐈𝐙𝐄𝐍 𝐌𝐃'},{quoted:msg});
  return true;
 }
 if(cmd==='تيك'||cmd==='انستا'){
  if(!/^https?:\/\//i.test(arg))return reply('أرسل رابط '+(cmd==='تيك'?'TikTok':'Instagram')+' بعد الأمر.');
  await sock.sendMessage(jid,{text:'⏳ جاري تنزيل الوسائط...'});const dl=await cobalt(arg,'auto');const buf=await fetchMedia(dl);
  const isVideo=/video|mp4|reel|\/tv\//i.test(arg)||cmd==='تيك';
  if(isVideo)await sock.sendMessage(jid,{video:buf,mimetype:'video/mp4',caption:'✦ 𝐀𝐈𝐙𝐄𝐍 𝐌𝐃'},{quoted:msg});else await sock.sendMessage(jid,{image:buf,caption:'✦ 𝐀𝐈𝐙𝐄𝐍 𝐌𝐃'},{quoted:msg});
  return true;
 }
}
async function moderation(sock,msg,jid,sender,body){
 const cfg=groupCfg(jid);if(!PROTECTION.some(k=>cfg[k])&&!store.get().muted[keyFor(jid,sender)])return;
 let md;try{md=await getMeta(sock,jid);}catch{return;}
 const admins=md.participants.filter(p=>p.admin).map(p=>jidNormalizedUser(p.id));if(admins.includes(jidNormalizedUser(sender))||isOwner(sender))return;
 if(!admins.includes(jidNormalizedUser(sock.user.id)))return;
 const now=Date.now(),k=keyFor(jid,sender),type=msgType(msg);let reason='';
 if(cfg.links&&isUrl(body))reason='إرسال الروابط';
 if(cfg.badwords&&badWords.some(w=>body.toLowerCase().includes(w)))reason='الألفاظ المسيئة';
 if(cfg.mentions&&(msg.message?.extendedTextMessage?.contextInfo?.mentionedJid||[]).length>3)reason='الإشارات المزعجة';
 if(cfg[type])reason=({stickers:'الملصقات',images:'الصور',videos:'الفيديوهات',audio:'المقاطع الصوتية'})[type]||reason;
 if(cfg.duplicate&&body){const old=repeats.get(k)||{text:'',count:0,time:now};if(old.text===body&&now-old.time<config.DUPLICATE_WINDOW_MS)old.count++;else{old.text=body;old.count=1;}old.time=now;repeats.set(k,old);if(old.count>=config.DUPLICATE_MAX)reason='تكرار الرسائل';}
 if(cfg.spam){const arr=(spamMap.get(k)||[]).filter(t=>now-t<10000);arr.push(now);spamMap.set(k,arr);if(arr.length>=3)reason='الرسائل المزعجة';}
 if(cfg.flood){const arr=(flood.get(k)||[]).filter(t=>now-t<config.FLOOD_WINDOW_MS);arr.push(now);flood.set(k,arr);if(arr.length>=config.FLOOD_MAX)reason='إرسال رسائل كثيرة بسرعة';}
 if(store.get().muted[k]){addViolation(jid,sender,'الكتابة أثناء الكتم');await sock.sendMessage(jid,{delete:msg.key}).catch(()=>{});return;}
 if(reason){addViolation(jid,sender,reason);await sock.sendMessage(jid,{text:`⚠️ تمت إزالة @${sender.split('@')[0]} بسبب: ${reason}`,mentions:[sender]});await sock.groupParticipantsUpdate(jid,[sender],'remove').catch(async()=>{await sock.sendMessage(jid,{delete:msg.key}).catch(()=>{});});}
 if(flood.size>1500)flood.clear();if(repeats.size>1500)repeats.clear();if(spamMap.size>1500)spamMap.clear();
}
async function sendMainMenu(sock,jid,sender){
 const prefix=store.get().prefix||config.PREFIX;
 const caption=menu.main({user:sender.split('@')[0],mode:store.get().mode==='public'?'عام':'خاص',prefix,version:config.VERSION,developerNumber:config.DEVELOPER_NUMBER,channel:MENU_CHANNEL});
 const sent=await sock.sendMessage(jid,{image:MENU_IMAGE_BUFFER,caption});
 if(sent?.key?.id){menuMessages.set(jid,sent.key.id);if(menuMessages.size>1000)menuMessages.delete(menuMessages.keys().next().value);}
}
async function handleMenuNavigation(sock,msg,jid,sender,body){
 const ctx=msg.message?.extendedTextMessage?.contextInfo;
 const quotedId=ctx?.stanzaId;
 const lastMenuId=menuMessages.get(jid);
 if(/^([1-9]|10)$/.test(body) && quotedId && lastMenuId && quotedId===lastMenuId){
  await send(sock,jid,menu.sectionText(Number(body)));
  return true;
 }
 const section=menu.sectionFromText(body);
 if(section){await send(sock,jid,menu.sectionText(section));return true;}
 return false;
}
async function handleCommand(sock,msg,jid,sender,body){
 const prefix=store.get().prefix||config.PREFIX;if(!body.startsWith(prefix))return false;
 const linkedNumber=digits(String(sock.user?.id||'').split('@')[0].split(':')[0]);
 const senderNumber=digits(String(sender||'').split('@')[0].split(':')[0]);
 // في الوضع الخاص لا تُنفّذ الأوامر إلا من حساب واتساب المرتبط بالبوت نفسه.
 if(store.get().mode==='private' && (!linkedNumber || senderNumber!==linkedNumber)) return true;
 const parts=body.slice(prefix.length).trim().split(/\s+/),rawCmd=parts.shift()||'',arg=parts.join(' '),group=isGroup(jid),owner=isOwner(sender),quoted=msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
 if(group && store.get().blocked[keyFor(jid,sender)] && !owner) return true;
 const commandAliases={'احصائيات':'إحصائيات','اعادة_تشغيل':'إعادة_تشغيل','انهاء_الصيانة':'إنهاء_الصيانة','ارسال_للجميع':'إرسال_للجميع','اصدار':'إصدار','حذف_التحذيرات':'مسح_التحذيرات','منع_فيضان':'منع_الفيضان','منع_شتائم':'منع_الشتائم','منع_الشتائم':'منع_الشتائم','منع_المنشن':'منع_المنشن','قفل_ذكاء':'قفل_ذكاء','فتح_ذكاء':'فتح_ذكاء'};
 const cmd=commandAliases[rawCmd]||rawCmd;
 store.get().stats.commands=(store.get().stats.commands||0)+1;
 const reply=t=>send(sock,jid,t,msg);
 if(store.get().maintenance&&!owner&&!['بوت','اوامر','مساعدة'].includes(cmd))return true;
 // وضع الخاص لا يعطل استقبال الأوامر؛ صلاحيات أوامر المالك محمية بشكل مستقل أدناه.
 if(['بوت','اوامر','مساعدة'].includes(cmd)){await sendMainMenu(sock,jid,sender);return true;}
 if(cmd==='تنصيب'){await reply('لاستخدام 𝐀𝐈𝐙𝐄𝐍 𝐌𝐃 أرسل .بوت لعرض الأقسام، ثم اختر القسم بالرد على القائمة برقم من 1 إلى 10، أو اكتب اسم القسم مباشرة.');return true;}
 if(/^([1-9]|10)$/.test(cmd)){return true;}
 const typedSection=menu.sectionFromText(cmd+(arg?' '+arg:''));if(typedSection){await send(sock,jid,menu.sectionText(typedSection));return true;}
 if(['ping','السرعة'].includes(cmd)){const t=Date.now();await reply(`♛ AIZEN MD يعمل\nزمن الاستجابة: ${Date.now()-t}ms`);return true;}
 if(['حالة','حول','إصدار'].includes(cmd)){await reply(`♛ ${config.BOT_NAME}\nالإصدار: ${config.VERSION}\nالوضع: ${store.get().mode}\nالصيانة: ${store.get().maintenance?'مفعلة':'متوقفة'}`);return true;}
 if(cmd==='المطور'){await reply(`مطور البوت: wa.me/${config.DEVELOPER_NUMBER}`);return true;}
 if(cmd==='اسمي'){await reply(`اسمك: ${msg.pushName||sender.split('@')[0]}`);return true;}
 if(cmd==='فتح_ذكاء'||cmd==='قفل_ذكاء'){const scope=group?groupCfg(jid):(store.get().privateSettings||(store.get().privateSettings={}));scope.aiEnabled=cmd==='فتح_ذكاء';store.save();await reply(scope.aiEnabled?'تم فتح محادثة الذكاء الاصطناعي.':'تم قفل محادثة الذكاء الاصطناعي.');return true;}
 if(AI_COMMANDS.includes(cmd)){const aiScope=group?groupCfg(jid):store.get().privateSettings;if(aiScope&&aiScope.aiEnabled===false){await reply('محادثة الذكاء الاصطناعي مقفلة. افتحها بالأمر .فتح_ذكاء.');return true;}const prompt=arg||textOf(quoted);if(!prompt){await reply(`اكتب النص بعد الأمر، مثال: ${prefix}${cmd} اشرح الذكاء الاصطناعي`);return true;}await sock.sendMessage(jid,{text:'♛ جاري التفكير...'});try{await reply(String(await ai.ask(prompt)).slice(0,6000));}catch(e){await reply(e.message);}return true;}
 if(fun[cmd]){const a=fun[cmd];await reply(a[Math.floor(Math.random()*a.length)]);return true;}
 if(cmd==='حظ'){await reply(`نسبة حظك اليوم: ${Math.floor(Math.random()*101)}% 🍀`);return true;}
 if(cmd==='تاريخ'){await reply(new Date().toLocaleString('ar',{dateStyle:'full',timeStyle:'short'}));return true;}
 if(cmd==='زخرفة'||cmd==='كتابة_مزخرفة'){if(!arg){await reply('اكتب النص بعد الأمر.');return true;}await reply(`『 ${arg.split('').join(' ')} 』\n『 ${arg.toUpperCase()} 』`);return true;}
 if(['صمم','ارسم','شعار','خلفية','بطاقة','تهنئة'].includes(cmd)){if(!arg){await reply(`اكتب وصف الصورة بعد الأمر. مثال: ${prefix}${cmd} شعار أسود وأزرق باسم AIZEN`);return true;}await sock.sendMessage(jid,{text:'🎨 جاري إنشاء التصميم...'});try{await makeImage(sock,jid,arg,msg);}catch(e){await reply(e.message);}return true;}
 if(cmd==='وضع_عام'||cmd==='وضع_خاص'){if(!owner)return true;store.get().mode=cmd==='وضع_عام'?'public':'private';store.save();await reply(`تم تغيير وضع البوت إلى ${store.get().mode}`);return true;}
 if(cmd==='صيانة'||cmd==='إنهاء_الصيانة'){if(!owner)return true;store.get().maintenance=cmd==='صيانة';store.save();await reply(cmd==='صيانة'?'تم تفعيل وضع الصيانة.':'تم إنهاء وضع الصيانة.');return true;}
 if(cmd==='إعادة_تشغيل'){if(!owner)return true;await reply('سيتم إعادة تشغيل البوت الآن.');store.flush();setTimeout(()=>process.exit(0),500);return true;}
 if(cmd==='إحصائيات'&&owner){await reply(`المجموعات: ${Object.keys(store.get().groups).length}\nالرسائل: ${store.get().stats.messages||0}\nالأوامر: ${store.get().stats.commands||0}\nمدة التشغيل: ${Math.floor(process.uptime()/60)} دقيقة`);return true;}
 if(cmd==='المجموعات'&&owner){await reply('المجموعات المسجلة:\n'+(Object.keys(store.get().groups).join('\n')||'لا توجد مجموعات مسجلة'));return true;}
 if(cmd==='سجل_النظام'&&owner){await reply(store.get().logs.slice(-20).map(x=>`${x.at}: ${x.text}`).join('\n')||'لا توجد سجلات.');return true;}
 if(cmd==='إرسال_للجميع'&&owner){if(!arg){await reply('اكتب الرسالة بعد الأمر.');return true;}const ids=Object.keys(store.get().groups);let ok=0;for(const id of ids){try{await sock.sendMessage(id,{text:arg});ok++;await sleep(350);}catch{}}await reply(`تم إرسال الرسالة إلى ${ok} من ${ids.length} مجموعة.`);return true;}
 if(cmd==='البادئة'){if(arg&&owner){if(arg.length>3){await reply('البادئة يجب ألا تتجاوز 3 رموز.');return true;}store.get().prefix=arg;store.save();await reply(`تم تغيير البادئة إلى: ${arg}`);}else await reply(`البادئة الحالية: ${store.get().prefix||config.PREFIX}${owner?'\nلتغييرها اكتب: '+prefix+'البادئة ثم البادئة الجديدة':''}`);return true;}
 if(cmd.startsWith('البادئة_')&&owner){const v=cmd.slice('البادئة_'.length)||arg;if(v.length>3){await reply('البادئة يجب ألا تتجاوز 3 رموز.');return true;}store.get().prefix=v;store.save();await reply(`تم تغيير البادئة إلى: ${v}`);return true;}
 if(cmd==='اللغة'){if(!owner)return true;const v=arg.toLowerCase();if(!['ar','عربي','en','انجليزي'].includes(v)){await reply('استخدم: .اللغة عربي أو .اللغة en');return true;}store.get().language=['en','انجليزي'].includes(v)?'en':'ar';store.save();await reply(`تم ضبط اللغة إلى ${store.get().language}`);return true;}
 if(cmd==='الإعدادات'){const cfg=group?groupCfg(jid):{};await reply(`إعدادات AIZEN MD\nالوضع: ${store.get().mode}\nالصيانة: ${store.get().maintenance?'مفعلة':'متوقفة'}\nالبادئة: ${store.get().prefix}\nحماية الروابط: ${cfg.links?'مفعلة':'متوقفة'}\nالتكرار: ${cfg.duplicate?'مفعل':'متوقف'}\nالفيضان: ${cfg.flood?'مفعل':'متوقف'}`);return true;}
 if(await statusSection.handleCommand({cmd,arg,reply,store,prefix}))return true;
 if(['فيديو','شغل','جوجل','تيك','انستا','جيت'].includes(cmd)){try{await handleDownload(sock,msg,jid,cmd,arg,reply);}catch(e){await reply('تعذر تنفيذ الأمر: '+(e.message||'خطأ غير معروف'));}return true;}
 if(cmd==='رتبتي'){const n=store.get().users[sender]?.score||0;await reply(`رتبتك: ${n} نقطة`);return true;}
 if(cmd==='توب'){const top=Object.entries(store.get().users).sort((a,b)=>(b[1].score||0)-(a[1].score||0)).slice(0,10);await reply('🏆 المتصدرون\n'+(top.map((x,i)=>`${i+1}. ${x[0].split('@')[0]} — ${x[1].score||0}`).join('\n')||'لا توجد نقاط بعد.'));return true;}
 if(!group)return true;
 let info;try{info=await adminInfo(sock,jid,sender);}catch{await reply('تعذر قراءة صلاحيات المجموعة.');return true;}
 const {md,senderAdmin,botAdmin}=info,admin=senderAdmin||owner;
 if(['حماية','حماية_شاملة'].includes(cmd)||['منع_الروابط','منع_التكرار','منع_سبام','منع_الفيضان','منع_فيضان','منع_الشتائم','منع_المنشن','منع_الملصقات','كشف_التخريب'].includes(cmd)){
  if(!admin)return true;const cfg=groupCfg(jid);const map={'منع_الروابط':'links','منع_التكرار':'duplicate','منع_سبام':'spam','منع_الفيضان':'flood','منع_فيضان':'flood','منع_الشتائم':'badwords','منع_المنشن':'mentions','منع_الملصقات':'stickers','كشف_التخريب':'destructive'};
  const stateArg=String(arg||'').replace(/[أإآ]/g,'ا').trim().toLowerCase();const explicitOn=['تشغيل','تشغل','تفعيل','on'].includes(stateArg),explicitOff=['ايقاف','إيقاف','تعطيل','off'].includes(stateArg);
  if(cmd==='حماية'||cmd==='حماية_شاملة'){const enabled=explicitOff?false:true;for(const k of PROTECTION)cfg[k]=enabled;}else{const k=map[cmd];cfg[k]=explicitOn?true:explicitOff?false:!cfg[k];}
  store.save();await reply(`تم ${(['حماية','حماية_شاملة'].includes(cmd)?(explicitOff?'إيقاف جميع أنظمة الحماية':'تشغيل جميع أنظمة الحماية'):(cfg[map[cmd]]?'تشغيل':'إيقاف')+' '+cmd)}.`);return true;
 }
 if(cmd==='سجل_المخالفات'){const target=getTarget(msg)||sender;const a=store.get().violations[keyFor(jid,target)]||[];await reply(a.length?a.map(x=>`${x.at} — ${x.reason}`).join('\n'):'لا توجد مخالفات مسجلة لهذا العضو.');return true;}
 if(['قفل_الروابط','فتح_الروابط','قفل_الصور','فتح_الصور','قفل_الفيديو','فتح_الفيديو','قفل_الصوت','فتح_الصوت'].includes(cmd)){if(!admin)return true;const map={قفل_الروابط:['links',true],فتح_الروابط:['links',false],قفل_الصور:['images',true],فتح_الصور:['images',false],قفل_الفيديو:['videos',true],فتح_الفيديو:['videos',false],قفل_الصوت:['audio',true],فتح_الصوت:['audio',false]};const [k,v]=map[cmd];groupCfg(jid)[k]=v;store.save();await reply(v?'تم تفعيل المنع.':'تم السماح بهذا النوع من الرسائل.');return true;}
 if(cmd==='قفل'||cmd==='فتح'){if(!admin)return true;await sock.groupSettingUpdate(jid,cmd==='قفل'?'announcement':'not_announcement');await reply(cmd==='قفل'?'تم قفل المجموعة أمام الأعضاء.':'تم فتح المجموعة للأعضاء.');return true;}
 if(['طرد','حظر','فك_الحظر','كتم','فك_الكتم','تحذير','التحذيرات','حذف_التحذيرات','مسح_التحذيرات','ترقية','تنزيل'].includes(cmd)){
  if(!admin)return true;const target=getTarget(msg)||(['التحذيرات','حذف_التحذيرات','مسح_التحذيرات'].includes(cmd)?sender:null);if(!target){await reply('منشن العضو أو رد على رسالته أولًا.');return true;}const k=keyFor(jid,target);
  if(['طرد','ترقية','تنزيل'].includes(cmd)&&!botAdmin){await reply('يجب ترقية البوت إلى مشرف أولًا.');return true;}
  if(cmd==='طرد'){await sock.groupParticipantsUpdate(jid,[target],'remove');await reply(`تم طرد @${target.split('@')[0]}`);}
  if(cmd==='حظر'){store.get().blocked[k]=true;store.save();await reply(`تم حظر @${target.split('@')[0]} من استخدام البوت في هذه المجموعة.`);}
  if(cmd==='فك_الحظر'){delete store.get().blocked[k];store.save();await reply('تم السماح للعضو باستخدام البوت في هذه المجموعة.');}
  if(cmd==='كتم'){store.get().muted[k]=true;store.save();await reply(`تم كتم @${target.split('@')[0]}؛ ستحذف رسائله ما دام الكتم فعالًا.`);}
  if(cmd==='فك_الكتم'){delete store.get().muted[k];store.save();await reply('تم فك الكتم.');}
  if(cmd==='تحذير'){const n=(store.get().warnings[k]||0)+1;store.get().warnings[k]=n;store.save();await reply(`⚠️ تحذير @${target.split('@')[0]}\nعدد التحذيرات: ${n}/3`);if(n>=3&&botAdmin){await sock.groupParticipantsUpdate(jid,[target],'remove').catch(()=>{});delete store.get().warnings[k];store.save();await reply('تم إخراج العضو بعد وصوله إلى 3 تحذيرات.');}}
  if(cmd==='التحذيرات')await reply(`عدد التحذيرات: ${store.get().warnings[k]||0}`);
  if(cmd==='مسح_التحذيرات'||cmd==='حذف_التحذيرات'){delete store.get().warnings[k];store.save();await reply('تم مسح تحذيرات العضو.');}
  if(cmd==='ترقية'||cmd==='تنزيل'){await sock.groupParticipantsUpdate(jid,[target],cmd==='ترقية'?'promote':'demote');await reply(`تم ${cmd} @${target.split('@')[0]}`);}
  return true;
 }
 if(cmd==='منشن_الكل'&&admin){await sock.sendMessage(jid,{text:arg||'منشن للجميع',mentions:md.participants.map(p=>p.id)},{quoted:msg});return true;}
 if(cmd==='معلومات_الجروب'){await reply(`الاسم: ${md.subject}\nالأعضاء: ${md.participants.length}\nالوصف: ${md.desc||'لا يوجد'}\nالمشرفون: ${md.participants.filter(p=>p.admin).length}`);return true;}
 if(cmd==='رابط_الجروب'){if(!admin)return true;const code=await sock.groupInviteCode(jid);await reply(`https://chat.whatsapp.com/${code}`);return true;}
 if(cmd==='تغيير_الاسم'&&admin){if(!arg){await reply('اكتب الاسم الجديد.');return true;}await sock.groupUpdateSubject(jid,arg);await reply('تم تغيير اسم المجموعة.');return true;}
 if(cmd==='تغيير_الوصف'&&admin){if(!arg){await reply('اكتب الوصف الجديد.');return true;}await sock.groupUpdateDescription(jid,arg);await reply('تم تغيير وصف المجموعة.');return true;}
 return true;
}
async function start(){
 const {version}=await fetchLatestBaileysVersion();
 const {state,saveCreds}=await useMultiFileAuthState(config.SESSION_DIR);
 socket=makeWASocket({
  version, auth:state, logger:pino({level:'silent'}), printQRInTerminal:false,
  browser:['Ubuntu','Chrome','20.0.04'], markOnlineOnConnect:true,
  syncFullHistory:false, connectTimeoutMs:60000, defaultQueryTimeoutMs:60000
 });
 const currentSocket=socket;
 socket.ev.on('creds.update',saveCreds);
 // اتباع تسلسل الاقتران من بوت العباسي: انتظار 3 ثوانٍ بعد إنشاء الاتصال.
 if(!state.creds.registered){
  const number=digits(config.BOT_NUMBER);
  if(!/^\d{8,15}$/.test(number)) throw new Error('رقم الواتساب غير صالح؛ استخدم رمز الدولة ثم الرقم دون + أو مسافات.');
  setTimeout(async()=>{
   if(socket!==currentSocket || state.creds.registered) return;
   try{
    let code=await currentSocket.requestPairingCode(number);
    code=String(code||'').match(/.{1,4}/g)?.join('-')||String(code||'');
    console.log('\\n╭━━━〔 𝐀𝐈𝐙𝐄𝐍 𝐌𝐃 〕━━━╮');
    console.log('┃ 📱 رقم الواتساب: '+number);
    console.log('┃ 🔑 رمز الاقتران: '+code);
    console.log('┃ ⏳ افتح الأجهزة المرتبطة ← ربط جهاز ← الربط برقم الهاتف');
    console.log('╰━━━━━━━━━━━━━━━━━━╯\\n');
   }catch(e){console.error('❌ تعذر إنشاء رمز الاقتران:',e?.message||e);}
  },3000);
 }
 socket.ev.on('connection.update',async u=>{if(u.connection==='open'){console.log('♛ تم اتصال AIZEN MD بنجاح');pairingRequested=true;const ss=statusSection.normalizeSettings(store.get().statusSettings);store.get().statusSettings=ss;store.save();}
  if(u.connection==='close'){const code=u.lastDisconnect?.error?.output?.statusCode;console.log('انقطع الاتصال:',code,u.lastDisconnect?.error?.message||'');if(restarting)return;if(code===DisconnectReason.loggedOut){console.log('تم تسجيل الخروج؛ احذف session فقط إذا أردت إعادة الربط.');return;}if(reconnectTimer)clearTimeout(reconnectTimer);const delay=code===405?30000:12000;reconnectTimer=setTimeout(()=>{pairingRequested=false;start().catch(e=>console.error('Reconnect:',e));},delay);}
 });
 socket.ev.on('messages.upsert',async({messages,type})=>{for(const msg of messages){try{if(!msg.message)continue;const jid=msg.key.remoteJid;if(jid==='status@broadcast'){await statusSection.handleStatusMessage(socket,msg,store.get().statusSettings,store);continue;}if(type!=='notify')continue;if(!jid)continue;const fromMe=!!msg.key.fromMe;const body=textOf(msg.message).trim();if(fromMe&&!body.startsWith(store.get().prefix||config.PREFIX))continue;const sender=fromMe?jidNormalizedUser(socket.user.id):(msg.key.participant||jid);store.get().stats.messages=(store.get().stats.messages||0)+1;if(isGroup(jid)&&!store.get().groups[jid])store.get().groups[jid]={};const user=store.get().users[sender]||(store.get().users[sender]={score:0});user.score=(user.score||0)+1;
  const linkedNumber=digits(String(socket.user?.id||'').split('@')[0].split(':')[0]);
  const senderNumber=digits(String(sender||'').split('@')[0].split(':')[0]);
  const allowedByMode=store.get().mode!=='private' && store.get().mode!=='public' ? true : (store.get().mode==='public' || (!!linkedNumber && senderNumber===linkedNumber));
  const navigated=allowedByMode ? await handleMenuNavigation(socket,msg,jid,sender,body) : false;
  if(!navigated){
   if(isGroup(jid)&&!body.startsWith(store.get().prefix||config.PREFIX)) await moderation(socket,msg,jid,sender,body);
   else if(body.startsWith(store.get().prefix||config.PREFIX) && allowedByMode) await handleCommand(socket,msg,jid,sender,body);
  }
  if(store.get().stats.messages%20===0)store.save();
 }catch(e){console.error('Message handler:',e?.stack||e);const errJid=msg?.key?.remoteJid;if(errJid&&errJid!=='status@broadcast'&&textOf(msg.message).trim().startsWith(store.get().prefix||config.PREFIX)){await socket.sendMessage(errJid,{text:'تعذر تنفيذ الأمر بسبب خطأ أو نقص صلاحية: '+String(e?.message||e).slice(0,250)}).catch(()=>{});}}}});
 socket.ev.on('group-participants.update',async u=>{const cfg=groupCfg(u.id);for(const participant of (u.participants||[])){const k=keyFor(u.id,participant);if(u.action==='add'&&store.get().blocked[k]){await socket.groupParticipantsUpdate(u.id,[participant],'remove').catch(()=>{});continue;}}if(cfg.destructive){store.log(`تغيير أعضاء ${u.id}: ${u.action} ${(u.participants||[]).join(',')}`);await socket.sendMessage(u.id,{text:`♛ تم رصد تغيير في أعضاء المجموعة: ${u.action}`}).catch(()=>{});}});
 socket.ev.on('messages.update',async updates=>{for(const item of updates||[]){const m=item.update?.message;const proto=m?.protocolMessage;if(proto&&isGroup(item.key?.remoteJid)){const jid=item.key.remoteJid,cfg=groupCfg(jid);if(cfg.destructive){const who=item.key.participant||'عضو';store.log(`حذف رسالة في ${jid} بواسطة ${who}`);await socket.sendMessage(jid,{text:`♛ تم رصد حذف رسالة بواسطة @${String(who).split('@')[0]}`,mentions:[who]}).catch(()=>{});}}}});
}
start().catch(e=>{console.error('فشل تشغيل AIZEN MD:',e);process.exit(1);});
